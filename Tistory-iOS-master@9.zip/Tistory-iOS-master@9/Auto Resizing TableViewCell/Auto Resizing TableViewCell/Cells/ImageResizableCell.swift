//
//  ImageResizableCell.swift
//  Auto Resizing TableViewCell
//
//  Created by 이동건 on 2018. 6. 5..
//  Copyright © 2018년 이동건. All rights reserved.
//

import UIKit

class ImageResizableCell: UITableViewCell {

    @IBOutlet weak var artworkImageView: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }
}
