//
//  ResizableCell.swift
//  Auto Resizing TableViewCell
//
//  Created by 이동건 on 2018. 6. 5..
//  Copyright © 2018년 이동건. All rights reserved.
//

import UIKit

class ResizableCell: UITableViewCell {

    @IBOutlet weak var quoteLabel: UILabel!
    @IBOutlet weak var authorLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
}
