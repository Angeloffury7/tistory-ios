//
//  SampleVC.swift
//  Slide menu bar
//
//  Created by 이동건 on 2018. 2. 22..
//  Copyright © 2018년 이동건. All rights reserved.
//

import UIKit

class SampleVC: MainVCViewController{
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
