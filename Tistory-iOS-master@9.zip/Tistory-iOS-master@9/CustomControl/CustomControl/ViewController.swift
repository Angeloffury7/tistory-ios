//
//  ViewController.swift
//  CustomControl
//
//  Created by 이동건 on 2018. 6. 6..
//  Copyright © 2018년 이동건. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
}

