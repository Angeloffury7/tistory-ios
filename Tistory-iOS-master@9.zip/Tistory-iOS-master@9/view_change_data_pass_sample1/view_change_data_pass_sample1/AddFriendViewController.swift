//
//  AddFriendViewController.swift
//  view_change_data_pass_sample1
//
//  Created by 이동건 on 2017. 11. 1..
//  Copyright © 2017년 이동건. All rights reserved.
//

import UIKit

class AddFriendViewController: UIViewController {

    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var phoneTextField: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

    }
}
